package co.edu.uniquindio.poo.model;

public interface IEnchufable {
    public boolean esEnchufable();
    public boolean esLigero();
}
