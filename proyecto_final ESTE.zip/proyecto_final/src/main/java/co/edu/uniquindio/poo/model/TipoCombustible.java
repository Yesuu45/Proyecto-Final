package co.edu.uniquindio.poo.model;

public enum TipoCombustible {
    DIESEL, GASOLINA;
}
