package co.edu.uniquindio.poo;

import java.util.logging.Logger;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;



public class AppTestTransaccion {
    private static final Logger LOG = Logger.getLogger(AppTestAutor.class.getName());

    @Test
    public void datosVacios() {
        LOG.info("Iniciado test datosVacios");

        assertThrows(Throwable.class , ()-> new Transaccion("")

        LOG.info("Finalizando test DatosVacios");
    }
    
}
