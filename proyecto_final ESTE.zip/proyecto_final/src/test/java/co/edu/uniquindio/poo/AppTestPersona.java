package co.edu.uniquindio.poo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.logging.Level;
import java.util.logging.Logger;
import org.junit.jupiter.api.Test;
import co.edu.uniquindio.poo.model.Persona;

public class AppTestPersona {
    private static final Logger LOG = Logger.getLogger(AppTestPersona.class.getName());

    @Test
    public void testNombrePersona() {
        System.out.print("Iniciado test TestNombrePersona");

        Persona persona = new Persona("Esteban", "19281928", "Esteban", "Aros", "Polilla", "correo");

        assertEquals("Esteban", persona.getNombre(), "El nombre del autor debería ser 'Esteban'");
    }
}
