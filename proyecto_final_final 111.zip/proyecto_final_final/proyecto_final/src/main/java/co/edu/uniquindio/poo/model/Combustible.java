package co.edu.uniquindio.poo.model;

public enum Combustible {
    GASOLINA, DIESEL, ELECTRICO , HIBRIDO;
}
