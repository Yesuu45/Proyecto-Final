package co.edu.uniquindio.poo;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import co.edu.uniquindio.poo.model.Cliente;
import co.edu.uniquindio.poo.model.Vehiculo;
import co.edu.uniquindio.poo.model.Empleado;
import co.edu.uniquindio.poo.model.Transaccion;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class AppTestTransaccion {

    @Test
    public void testTransaccionVenta() {
        System.out.println("Iniciado test testTransaccionVenta");

        // Crear instancias necesarias para la transacción
        Cliente cliente = new Cliente("Carlos", "12345", "5551234", "carlos@example.com");
        Vehiculo vehiculo = new Sedan(5, 4, true, "Toyota", "Venta", "Camry", "Automático", "240 km/h", "2.5L");
        Empleado empleado = new Empleado("Juan", "67890", "5556789", "juan@example.com", "Vendedor");

        // Crear la transacción de venta
        Transaccion transaccion = new Transaccion("Venta", vehiculo, empleado, cliente);

        // Verificar que la transacción sea de tipo 'Venta'
        assertEquals("Venta", transaccion.getTipo(), "La transacción debería ser de tipo 'Venta'");

        // Verificar que el vehículo esté en la transacción
        assertEquals(vehiculo, transaccion.getVehiculo(), "El vehículo debe ser el mismo que el registrado en la transacción");

        // Verificar que el cliente esté en la transacción
        assertEquals(cliente, transaccion.getCliente(), "El cliente debe ser el mismo que el registrado en la transacción");

        System.out.println("Finalizando test testTransaccionVenta");
    }

    @Test
    public void testTransaccionAlquiler() {
        System.out.println("Iniciado test testTransaccionAlquiler");

        // Crear instancias necesarias para la transacción
        Cliente cliente = new Cliente("Ana", "54321", "5554321", "ana@example.com");
        Vehiculo vehiculo = new Moto("4T", true, 150, "Honda", "Alquiler", "CB500", "Manual", "180 km/h", "500cc");
        Empleado empleado = new Empleado("Pedro", "11223", "5551122", "pedro@example.com", "Alquiler");

        // Crear la transacción de alquiler
        Transaccion transaccion = new Transaccion("Alquiler", vehiculo, empleado, cliente);

        // Verificar que la transacción sea de tipo 'Alquiler'
        assertEquals("Alquiler", transaccion.getTipo(), "La transacción debería ser de tipo 'Alquiler'");

        // Verificar que el vehículo esté en la transacción
        assertEquals(vehiculo, transaccion.getVehiculo(), "El vehículo debe ser el mismo que el registrado en la transacción");

        // Verificar que el cliente esté en la transacción
        assertEquals(cliente, transaccion.getCliente(), "El cliente debe ser el mismo que el registrado en la transacción");

        System.out.println("Finalizando test testTransaccionAlquiler");
    }

    @Test
    public void testTransaccionCompra() {
        System.out.println("Iniciado test testTransaccionCompra");

        // Crear instancias necesarias para la transacción
        Cliente cliente = new Cliente("Luis", "67890", "5559876", "luis@example.com");
        Vehiculo vehiculo = new PickUp("ABS", 6, "Automático", "Sí", 800, "4x4", 5, 4, "Ford", "Compra", "F-150", "Automático", "180 km/h", "3.0L");
        Empleado empleado = new Empleado("Sofia", "33445", "5553344", "sofia@example.com", "Compras");

        // Crear la transacción de compra
        Transaccion transaccion = new Transaccion("Compra", vehiculo, empleado, cliente);

        // Verificar que la transacción sea de tipo 'Compra'
        assertEquals("Compra", transaccion.getTipo(), "La transacción debería ser de tipo 'Compra'");

        // Verificar que el vehículo esté en la transacción
        assertEquals(vehiculo, transaccion.getVehiculo(), "El vehículo debe ser el mismo que el registrado en la transacción");

        // Verificar que el cliente esté en la transacción
        assertEquals(cliente, transaccion.getCliente(), "El cliente debe ser el mismo que el registrado en la transacción");

        System.out.println("Finalizando test testTransaccionCompra");
    }
}