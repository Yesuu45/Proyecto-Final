package co.edu.uniquindio.poo.model;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import co.edu.uniquindio.poo.model.Persona;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;

public class AppTestPersona {

    @Test
    public void testGettersYSetters() {
        System.out.println("Iniciado test testGettersYSetters");

        // Crear una persona
        Persona persona = new Persona("Carlos Perez", "12345", "cperez", "secreta123", "contraseñaSegura", "cperez@mail.com");

        // Verificar que los valores se obtienen correctamente con los getters
        assertEquals("Carlos Perez", persona.getNombre(), "El nombre debería ser 'Carlos Perez'");
        assertEquals("12345", persona.getId(), "La ID debería ser '12345'");
        assertEquals("cperez", persona.getUsuario(), "El usuario debería ser 'cperez'");
        assertEquals("secreta123", persona.getPalabraSecreta(), "La palabra secreta debería ser 'secreta123'");
        assertEquals("contraseñaSegura", persona.getContraseña(), "La contraseña debería ser 'contraseñaSegura'");
        assertEquals("cperez@mail.com", persona.getCorreo(), "El correo debería ser 'cperez@mail.com'");

        System.out.println("Finalizando test testGettersYSetters");
    }

    @Test
    public void testSetters() {
        System.out.println("Iniciado test testSetters");

        // Crear una persona
        Persona persona = new Persona("Juan Gomez", "67890", "jgomez", "clave123", "contrasena123", "jgomez@mail.com");

        // Modificar los valores usando setters
        persona.setNombre("Carlos Ramirez");
        persona.setId("54321");
        persona.setUsuario("cramirez");
        persona.setPalabraSecreta("clave1234");
        persona.setContraseña("contraseña456");
        persona.setCorreo("cramirez@mail.com");

        // Verificar que los valores se hayan actualizado correctamente
        assertEquals("Carlos Ramirez", persona.getNombre(), "El nombre debería ser 'Carlos Ramirez'");
        assertEquals("54321", persona.getId(), "La ID debería ser '54321'");
        assertEquals("cramirez", persona.getUsuario(), "El usuario debería ser 'cramirez'");
        assertEquals("clave1234", persona.getPalabraSecreta(), "La palabra secreta debería ser 'clave1234'");
        assertEquals("contraseña456", persona.getContraseña(), "La contraseña debería ser 'contraseña456'");
        assertEquals("cramirez@mail.com", persona.getCorreo(), "El correo debería ser 'cramirez@mail.com'");

        System.out.println("Finalizando test testSetters");
    }

    @Test
    public void testValidacionCorreo() {
        System.out.println("Iniciado test testValidacionCorreo");

        // Crear persona con correo válido
        Persona personaValida = new Persona("Ana Torres", "11223", "atorres", "claveana", "contraseñaAna", "atorres@mail.com");

        // Verificar si el correo es válido
        assertTrue(personaValida.getCorreo().contains("@"), "El correo debería contener '@'");

        // Crear persona con correo no válido
        Persona personaInvalida = new Persona("Luis Herrera", "44556", "lherrera", "claveLuis", "contraseñaLuis", "lherrera.com");

        // Verificar si el correo no es válido
        assertFalse(personaInvalida.getCorreo().contains("@"), "El correo no debería ser válido si no contiene '@'");

        System.out.println("Finalizando test testValidacionCorreo");
    }
}
