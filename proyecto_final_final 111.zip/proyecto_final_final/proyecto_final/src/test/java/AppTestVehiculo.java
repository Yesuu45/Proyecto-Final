package co.edu.uniquindio.poo.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import co.edu.uniquindio.poo.model.RevisionTecnica;
import co.edu.uniquindio.poo.model.Vehiculo;
import co.edu.uniquindio.poo.model.Trasmision;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;


public class AppTestVehiculo {

    @Test
    public void testGettersYSetters() {
        System.out.println("Iniciado test testGettersYSetters");

        // Crear instancia de RevisionTecnica
        RevisionTecnica revision = new RevisionTecnica(true);

        // Crear un vehículo
        Vehiculo vehiculo = new Vehiculo("Toyota", "Corolla", "ABC123", 6, 200, 1500, true, Trasmision.AUTOMATICA, 25000.0, true, revision);

        // Verificar que los valores se establezcan correctamente con los getters
        assertEquals("Toyota", vehiculo.getMarca(), "La marca debería ser 'Toyota'");
        assertEquals("Corolla", vehiculo.getModelo(), "El modelo debería ser 'Corolla'");
        assertEquals("ABC123", vehiculo.getMatricula(), "La matrícula debería ser 'ABC123'");
        assertEquals(6, vehiculo.getCambios(), "El número de cambios debería ser 6");
        assertEquals(200, vehiculo.getVelocidadMaxima(), "La velocidad máxima debería ser 200 km/h");
        assertEquals(1500, vehiculo.getCilindraje(), "El cilindraje debería ser 1500");
        assertTrue(vehiculo.isEsNuevo(), "El vehículo debería ser nuevo");
        assertEquals(Trasmision.AUTOMATICA, vehiculo.getTrasmision(), "La transmisión debería ser automática");
        assertEquals(25000.0, vehiculo.getPrecio(), "El precio debería ser 25000.0");
        assertTrue(vehiculo.isDisponible(), "El vehículo debería estar disponible");

        System.out.println("Finalizando test testGettersYSetters");
    }

    @Test
    public void testPasaRevisionTecnica() {
        System.out.println("Iniciado test testPasaRevisionTecnica");

        // Crear instancias de RevisionTecnica con el estado aprobado
        RevisionTecnica revisionAprobada = new RevisionTecnica(true);
        RevisionTecnica revisionRechazada = new RevisionTecnica(false);

        // Crear vehículos con distintas revisiones
        Vehiculo vehiculoAprobado = new Vehiculo("Honda", "Civic", "XYZ123", 5, 180, 1400, true, Trasmision.MANUAL, 18000.0, true, revisionAprobada);
        Vehiculo vehiculoRechazado = new Vehiculo("Ford", "Focus", "XYZ124", 5, 190, 1600, false, Trasmision.AUTOMATICA, 22000.0, true, revisionRechazada);

        // Verificar que el vehículo pasa la revisión cuando está aprobado
        assertTrue(vehiculoAprobado.pasaRevisionTecnica(), "El vehículo debería pasar la revisión técnica porque está aprobado");

        // Verificar que el vehículo no pasa la revisión cuando está rechazada
        assertFalse(vehiculoRechazado.pasaRevisionTecnica(), "El vehículo no debería pasar la revisión técnica porque está rechazada");

        System.out.println("Finalizando test testPasaRevisionTecnica");
    }

    @Test
    public void testRevisionTecnica() {
        System.out.println("Iniciado test testRevisionTecnica");

        // Crear instancia de RevisionTecnica
        RevisionTecnica revision = new RevisionTecnica(true);

        // Crear un vehículo
        Vehiculo vehiculo = new Vehiculo("Chevrolet", "Spark", "XYZ125", 5, 150, 1300, true, Trasmision.AUTOMATICA, 15000.0, true, null);

        // Realizar la revisión técnica
        vehiculo.revisionTecnica(revision);

        // Verificar que la revisión se haya registrado correctamente
        assertEquals(revision, vehiculo.getRevisionTecnica(), "La revisión técnica debería haberse establecido correctamente");

        // Verificar que el vehículo ahora esté disponible
        assertTrue(vehiculo.isDisponible(), "El vehículo debería estar disponible después de la revisión técnica");

        System.out.println("Finalizando test testRevisionTecnica");
    }
}